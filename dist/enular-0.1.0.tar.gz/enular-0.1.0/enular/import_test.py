#!/usr/bin/env python
import os
import sys

def test_function():
    print("Import successful.")
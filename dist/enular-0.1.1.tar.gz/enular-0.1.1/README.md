# Enular Library
 
pip install enular

The Enular Library contains code for backtesting, evaluating and visualising algorithmic trading strategies. It also provides indicators, data sources, and paper trading capabilities. Documentation coming soon.